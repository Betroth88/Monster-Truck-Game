import React from 'react'
import ReactDOM from 'react-dom/client'
import MonsterTruckGame from './MonsterTruckGame.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MonsterTruckGame />
  </React.StrictMode>,
)
