import { useState, useEffect, useRef } from "react";

export default function MonsterTruckGame() {
  const canvasRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [truck, setTruck] = useState({ x: 50, y: 200, speed: 0, gravity: 1.5 });
  const [goal, setGoal] = useState({ x: 700, y: 200 });
  const [message, setMessage] = useState("You Win!");
  const [canvasWidth, setCanvasWidth] = useState(800);

  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(window.innerWidth - 40, 800);
      setCanvasWidth(width);
    };
    updateCanvasSize();
    window.addEventListener("resize", updateCanvasSize);
    return () => window.removeEventListener("resize", updateCanvasSize);
  }, []);

  useEffect(() => {
    if (!isPlaying) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    let animationFrameId;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw ground
      ctx.fillStyle = "#654321";
      ctx.fillRect(0, 250, canvas.width, 50);

      // Draw goal flag
      ctx.fillStyle = "red";
      ctx.fillRect(goal.x, goal.y - 30, 10, 30);
      ctx.beginPath();
      ctx.moveTo(goal.x + 10, goal.y - 30);
      ctx.lineTo(goal.x + 30, goal.y - 20);
      ctx.lineTo(goal.x + 10, goal.y - 10);
      ctx.fill();

      // Draw truck
      ctx.fillStyle = "blue";
      ctx.fillRect(truck.x, truck.y, 60, 30);

      // Truck wheels
      ctx.beginPath();
      ctx.arc(truck.x + 10, truck.y + 30, 10, 0, Math.PI * 2);
      ctx.arc(truck.x + 50, truck.y + 30, 10, 0, Math.PI * 2);
      ctx.fillStyle = "black";
      ctx.fill();

      // Update truck position
      setTruck((prev) => {
        let newX = prev.x + prev.speed;
        if (newX + 60 >= goal.x) {
          setMessage("You reached the goal! 🎉");
          setIsPlaying(false);
          return prev;
        }
        return { ...prev, x: newX };
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, goal.x, truck.speed]);

  const moveTruck = (speed) => {
    setTruck((prev) => ({ ...prev, speed }));
  };

  const stopTruck = () => {
    setTruck((prev) => ({ ...prev, speed: 0 }));
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "ArrowRight") moveTruck(5);
      if (e.key === "ArrowLeft") moveTruck(-5);
    };
    const handleKeyUp = () => stopTruck();
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  const startGame = () => {
    setMessage("");
    setTruck({ x: 50, y: 200, speed: 0, gravity: 1.5 });
    setIsPlaying(true);
  };

  return (
    <div style={{ textAlign: "center", padding: 10 }}>
      <h1>Monster Truck Game</h1>
      <canvas
        ref={canvasRef}
        width={canvasWidth}
        height={300}
        style={{ border: "1px solid black", maxWidth: "100%" }}
      />
      <div style={{ marginTop: 10 }}>
        <button onClick={startGame} disabled={isPlaying}>
          {isPlaying ? "Playing..." : "Start Game"}
        </button>
        <div style={{ marginTop: 10 }}>
          <button
            onTouchStart={() => moveTruck(-5)}
            onTouchEnd={stopTruck}
            style={{ marginRight: 10 }}
          >
            ⬅️ Left
          </button>
          <button
            onTouchStart={() => moveTruck(5)}
            onTouchEnd={stopTruck}
          >
            ➡️ Right
          </button>
        </div>
        {message && <p style={{ marginTop: 10, color: "green" }}>{message}</p>}
      </div>
    </div>
  );
}
