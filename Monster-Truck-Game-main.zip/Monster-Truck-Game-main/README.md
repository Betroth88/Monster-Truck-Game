# Monster-Truck-Game
gh repo create monster-truck-game --public --source=. --push
git init
git add .
git commit -m "Initial commit"
